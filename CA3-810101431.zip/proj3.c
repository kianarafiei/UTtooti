#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "funcs.h"
int main()
{
    user *current_user = (user *)malloc(sizeof(user));
    user *head = (user *)malloc(sizeof(user));
    current_user->next = NULL;
    current_user = NULL;
    head->username = (char *)malloc(sizeof(char));
    head->password = (char *)malloc(sizeof(char));
    head->next = NULL;
    head->posts = NULL;
    head->likes = NULL;
    while (1)
    {
        char *command = (char *)malloc(sizeof(char));
        command = input(command);

        if (!strcmp(command, "signup") == 1)
        { // signup
            char *UserName = (char *)malloc(sizeof(char));
            UserName = input(UserName);
            char *PassWord = (char *)malloc(sizeof(char));
            PassWord = input(PassWord);
            int temp_voroodi = signup(UserName, PassWord, head);
            if (temp_voroodi == 1)
                printf("THIS USERNAME ALREADY EXISTS\n");
            else if (temp_voroodi == 2)
                printf("THIS PASSWORD ALREADY EXISTS\n");
            else
                printf("USER %s SIGNEDUP AND THE PASSWORD IS %s \n", UserName, PassWord);
            free(UserName);
            free(PassWord);
        }
        else if (!strcmp(command, "login") == 1)
        { // login
            char *UserName = (char *)malloc(sizeof(char));
            UserName = input(UserName);
            char *PassWord = (char *)malloc(sizeof(char));
            PassWord = input(PassWord);
            if (current_user == NULL)
            {
                current_user = login(UserName, PassWord, head);
                if (current_user == NULL)
                {
                    printf("WRONG USERNAME OR PASSWORD\n");
                }
                else
                {
                    printf("USER %s SUCCESSFULLY LOGGED IN\n", UserName);
                }
            }
            else
                printf("ANOTHER USER IS LOGGED IN NOW\n");
            free(UserName);
            free(PassWord);
        }
        else if (!strcmp(command, "logout") == 1)
        { // logout
            printf("USER %s SUCCESSFULLY LOGGED OUT\n", current_user->username);
            current_user = NULL;
        }
        else if (!strcmp(command, "finduser") == 1)
        { // findinding user
            char *UserName = (char *)malloc(sizeof(char));
            UserName = input(UserName);
            if (find_user(head, UserName) == NULL)
                printf("NO SUCH USER WAS FOUND\n");
            else
                show_info(find_user(head, UserName));
            free(UserName);
        }
        else if (!strcmp(command, "info") == 1)
        { // info
            if (current_user == NULL)
                printf("NO USER IS LOGGED IN NOW!\n");
            else
                show_info(current_user);
        }
        else if (!strcmp(command, "post") == 1)
        { // posting
            char *text = (char *)malloc(1);
            int i = 0;
            char temp_voroodi = 'x';
            while (1)
            {
                temp_voroodi = getchar();
                if (temp_voroodi == '\n')
                    break;
                *(text + i) = temp_voroodi;
                i++;
                text = (char *)realloc(text, i + 1);
            }
            text[i] = '\0';
            if (current_user != NULL)
            {
                posting(text, current_user);
                printf("YOUR POST HAS BEEN SUBMITED\n");
            }
            else
            {
                printf("NO USSER IS LOGGED IN NOW\n");
            }
            free(text);
        }
    }
}
