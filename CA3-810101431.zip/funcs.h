#include <string.h>
#include <stdio.h>
#include <stdlib.h>
typedef struct post
{
    char *text;
    int likes;
    int ID;
    char *username;
    struct post *next;
} post;
typedef struct liked
{
    char *username;
    int ID;
    struct liked *next;
} liked;
typedef struct user
{
    char *username;
    char *password;
    int lastID;
    struct user *next;
    post *posts;
    liked *likes;
} user;
user *find_user(user *head, char *UserName)
{
    if (head == NULL)
        return NULL;
    user *current_user = (user *)malloc(sizeof(user));
    current_user = (head)->next;
    while (current_user != NULL)
    {
        if (!strcmp(current_user->username, UserName))
        {
            return current_user;
        }
        current_user = current_user->next;
    }
    return NULL;
}
int signup(char *UserName, char *PassWord, user *head)
{
    if (find_user(head, UserName) != NULL)
        return 1;
    user *new_user = (user *)malloc(sizeof(user));
    new_user->username = (char *)malloc(321);
    new_user->password = (char *)malloc(321);
    strcpy(new_user->username, UserName);
    strcpy(new_user->password, PassWord);
    new_user->lastID = -1;
    new_user->next = NULL;
    new_user->posts = NULL;
    new_user->likes = NULL;
    user *current_user = (user *)malloc(sizeof(user));
    current_user = head;
    while (current_user->next != NULL)
        current_user = current_user->next;
    current_user->next = new_user;
    return 0;
}
user *login(char *UserName, char *PassWord, user *head)
{
    if (find_user(head, UserName) == NULL)
        return NULL;
    else if (strcmp(find_user(head, UserName)->password, PassWord) != 0)
        return NULL;
    return find_user(head, UserName);
}
int posting(char* text,user* user){
    int pOST_ID=(user->lastID)+1;
    user->lastID+=1;
    post* newpost=(post*)malloc(sizeof(post));
    newpost->text=(char*)malloc(strlen(text)+1);
    newpost->username=(char*)malloc(strlen(user->username)+1);
    strcpy(newpost->text,text);
    strcpy(newpost->username,user->username);
    newpost->likes=0;
    newpost->ID=pOST_ID;
    newpost->next=NULL;
    post* current_post=(post*)malloc(sizeof(post));
    current_post=user->posts;
    if(pOST_ID==0)
        user->posts=newpost;
    else{
        while(current_post->next!=NULL){
            current_post=current_post->next;
        }
        current_post->next=newpost;
    }
    return 0;
}
int show_post(post* post){
    printf("USER: %s\n",post->username);
    printf("POST-ID: %d\n",post->ID);
    printf("LIKES: %d\n",post->likes);
    printf("POST: %s\n",post->text);
}
int show_info(user* user){
    printf("USERNAME: %s    PASSWORD: %s\n",user->username,user->password); 
    post* user_post=user->posts;
    while(user_post!=NULL){
        show_post(user_post);
        user_post=user_post->next;
        printf("\n");    
    }
}
char *input(char *voroodi)
{
   int i = 0;
   char temp_voroodi = 'x';
   while (1)
   {
      temp_voroodi = getchar();
      if (temp_voroodi == ' ')
         break;
      if (temp_voroodi == '\n')
         break;
      voroodi[i] = temp_voroodi;
      i++;
      voroodi = (char *)realloc(voroodi, i + 1);
   }
   voroodi[i] = '\0';
   return voroodi;
}

